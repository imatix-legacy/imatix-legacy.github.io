Single Stepped Schema for Visual Basic

    Author:  Tom Bushell <tbushell@fox.nstn.ns.ca>
    Revised: 11 Jul 1997

    This schema is based on the standard VB schema.  It provides an
    interesting an useful new model of operations; while the standard
    schema executes the dialog from start to end, this schema executes
    only the logic for the incoming event.

    In effect you can write VB code to handle user interface events
    as they occur, and depending on the dialog state.

    This approach is probably applicable to other languages too.

    -
    Pieter Hintjens
    iMatix
